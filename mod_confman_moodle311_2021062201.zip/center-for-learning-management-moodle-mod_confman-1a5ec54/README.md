# moodle-mod_confman
Moodle Plugin that helps organizing submissions for events

Add a "confman"-Activity to a course and you can specify a timerange when submissions are possible.
You are given a link that can be shared outside moodle to allow external people (also without 
Moodle-Login) to submit submissions for your event.

Everybody in your course that has instructor-role is allowed to manage all submissions. Everybody
in your course that has student-role is allowed to comment submissions.

Submitters can manage their own submissions using a unique link that is given to them.
